var a=a=>a;export{a as default};
//# sourceMappingURL=function.js.map
