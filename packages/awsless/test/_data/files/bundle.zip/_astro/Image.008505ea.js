import{I as f}from"./Image.05f35f9a.js";export{f as default};
